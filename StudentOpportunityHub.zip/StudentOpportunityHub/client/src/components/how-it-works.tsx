import { motion } from "framer-motion";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

const studentSteps = [
  { number: 1, title: "Sign Up", description: "Create your profile and showcase your skills", color: "bg-steel-blue" },
  { number: 2, title: "Get Vetted", description: "Complete our simple verification process", color: "bg-sky-blue" },
  { number: 3, title: "Accept Gigs", description: "Browse and apply for opportunities that match your schedule", color: "bg-steel-blue" },
  { number: 4, title: "Work & Earn", description: "Complete tasks and get paid instantly", color: "bg-sky-blue" },
  { number: 5, title: "Get Rated", description: "Build your reputation and unlock better opportunities", color: "bg-steel-blue" }
];

const organizerSteps = [
  { number: 1, title: "Post Event", description: "Describe your event and staffing needs", color: "bg-ocean-blue" },
  { number: 2, title: "Review Applications", description: "Browse qualified student profiles and select the best fit", color: "bg-steel-blue" },
  { number: 3, title: "Brief Team", description: "Communicate expectations and event details", color: "bg-ocean-blue" },
  { number: 4, title: "Rate Performance", description: "Provide feedback to help students grow", color: "bg-steel-blue" }
];

export default function HowItWorks() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  return (
    <section id="how-it-works" className="py-20 gradient-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <motion.h2 
          className="text-4xl font-bold text-center mb-16 text-light-blue"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          How It Works
        </motion.h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Student Flow */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="bg-charcoal/40 p-8 rounded-2xl border-2 border-steel-blue/30 backdrop-blur-sm"
          >
            <h3 className="text-2xl font-semibold mb-8 text-steel-blue text-center">For Students</h3>
            <div className="space-y-6">
              {studentSteps.map((step, index) => (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isVisible ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.3 + (index * 0.1), duration: 0.5 }}
                  className="flex items-center space-x-4 p-4 bg-navy/50 rounded-lg border border-steel-blue/20"
                >
                  <div className={`w-10 h-10 ${step.color} rounded-full flex items-center justify-center text-light-blue font-bold text-sm flex-shrink-0`}>
                    {step.number}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-light-blue mb-1">{step.title}</h4>
                    <p className="text-light-blue-muted text-sm">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          {/* Organizer Flow */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="bg-charcoal/40 p-8 rounded-2xl border-2 border-ocean-blue/30 backdrop-blur-sm"
          >
            <h3 className="text-2xl font-semibold mb-8 text-ocean-blue text-center">For Organizers</h3>
            <div className="space-y-6">
              {organizerSteps.map((step, index) => (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isVisible ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.5 + (index * 0.1), duration: 0.5 }}
                  className="flex items-center space-x-4 p-4 bg-navy/50 rounded-lg border border-ocean-blue/20"
                >
                  <div className={`w-10 h-10 ${step.color} rounded-full flex items-center justify-center text-light-blue font-bold text-sm flex-shrink-0`}>
                    {step.number}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-light-blue mb-1">{step.title}</h4>
                    <p className="text-light-blue-muted text-sm">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
