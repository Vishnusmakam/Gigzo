import { motion } from "framer-motion";
import { Shield, Clock, Rocket, Users, Zap, TrendingUp } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

const studentFeatures = [
  {
    icon: Shield,
    title: "Vetted Opportunities",
    description: "All gigs are verified and from trusted event organizers.",
    color: "text-aqua"
  },
  {
    icon: Clock,
    title: "Flexible Schedule",
    description: "Work around your class schedule with flexible timing options.",
    color: "text-electric-purple"
  },
  {
    icon: Rocket,
    title: "Career Growth",
    description: "Build your resume with real-world experience and professional connections.",
    color: "text-aqua"
  }
];

const organizerFeatures = [
  {
    icon: Users,
    title: "Curated Talent Pool",
    description: "Access to pre-vetted, skilled students ready to work.",
    color: "text-aqua"
  },
  {
    icon: Zap,
    title: "Quick Hiring",
    description: "Find and hire talent in minutes, not days.",
    color: "text-electric-purple"
  },
  {
    icon: TrendingUp,
    title: "Real-time Ratings",
    description: "Rate and review performance to maintain quality standards.",
    color: "text-aqua"
  }
];

export default function WhyUs() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  return (
    <section id="why-us" className="py-20 bg-navy">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <motion.h2 
          className="text-4xl font-bold text-center mb-16 text-light-blue"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          Why Choose Gigzo?
        </motion.h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* For Students */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <h3 className="text-2xl font-semibold mb-8 text-electric-purple">For Students</h3>
            <div className="space-y-6">
              {studentFeatures.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -30 }}
                  animate={isVisible ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.3 + (index * 0.1), duration: 0.5 }}
                  className="flex items-start space-x-4"
                >
                  <div className={`text-2xl ${feature.color}`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-light-blue mb-2">{feature.title}</h4>
                    <p className="text-light-blue-muted">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          {/* For Organizers */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            <h3 className="text-2xl font-semibold mb-8 text-electric-purple">For Organizers</h3>
            <div className="space-y-6">
              {organizerFeatures.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: 30 }}
                  animate={isVisible ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.5 + (index * 0.1), duration: 0.5 }}
                  className="flex items-start space-x-4"
                >
                  <div className={`text-2xl ${feature.color}`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-light-blue mb-2">{feature.title}</h4>
                    <p className="text-light-blue-muted">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
