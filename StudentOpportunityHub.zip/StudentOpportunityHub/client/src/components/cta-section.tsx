import { motion } from "framer-motion";
import { UserCheck, Calendar } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

export default function CTASection() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.3 });

  return (
    <section id="cta-section" className="py-20 bg-navy">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold mb-8 text-light-blue">Ready to Get Started?</h2>
          <p className="text-xl mb-12 text-light-blue-muted">Join thousands of students and organizers already using Gigzo</p>
        </motion.div>
        
        <motion.div 
          className="flex flex-col sm:flex-row gap-6 justify-center"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <motion.button
            className="group relative bg-gradient-to-r from-steel-blue to-ocean-blue text-light-blue px-16 py-6 rounded-2xl text-xl font-bold shadow-2xl overflow-hidden backdrop-blur-sm border-2 border-ice-blue/40 transform perspective-1000"
            initial={{ opacity: 0, y: 20, rotateX: 15 }}
            animate={isVisible ? { 
              opacity: 1, 
              y: 0, 
              rotateX: 0,
              boxShadow: [
                "0 10px 30px rgba(72, 133, 189, 0.3)",
                "0 15px 40px rgba(72, 133, 189, 0.4)",
                "0 10px 30px rgba(72, 133, 189, 0.3)"
              ]
            } : {}}
            transition={{ 
              opacity: { delay: 0.3, duration: 0.5, ease: "easeOut" },
              y: { delay: 0.3, duration: 0.5, ease: "easeOut" },
              rotateX: { delay: 0.3, duration: 0.5, ease: "easeOut" },
              boxShadow: { delay: 0.8, duration: 2, repeat: Infinity, ease: "easeInOut" }
            }}
            whileHover={{ 
              scale: 1.05, 
              y: -10,
              rotateX: -5,
              rotateY: 5,
              boxShadow: "0 25px 50px rgba(72, 133, 189, 0.6)",
              transition: { duration: 0.3, ease: "easeOut" }
            }}
            whileTap={{ scale: 0.95, y: -2 }}
          >
            {/* Enhanced glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-steel-blue/40 to-ocean-blue/40 blur-xl opacity-0 group-hover:opacity-80 transition-opacity duration-300 -z-10 scale-110"></div>
            
            {/* Animated background layer */}
            <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></div>
            
            {/* Professional border highlight */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-ice-blue/50 to-sky-blue/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -m-0.5 -z-10"></div>
            
            {/* Enhanced shimmer */}
            <div className="absolute inset-0 -left-6 w-8 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shimmer opacity-0 group-hover:opacity-100"></div>
            
            <div className="flex items-center justify-center space-x-3 relative z-10">
              <UserCheck className="w-6 h-6" />
              <div className="font-poppins">
                <div className="tracking-wide drop-shadow-sm">JOIN AS STUDENT</div>
                <div className="text-sm mt-1 opacity-80">Start earning today</div>
              </div>
            </div>
          </motion.button>
          
          <motion.button
            className="group relative bg-gradient-to-r from-sky-blue to-steel-blue text-light-blue px-16 py-6 rounded-2xl text-xl font-bold shadow-2xl overflow-hidden backdrop-blur-sm border-2 border-ice-blue/40 transform perspective-1000"
            initial={{ opacity: 0, y: 20, rotateX: 15 }}
            animate={isVisible ? { 
              opacity: 1, 
              y: 0, 
              rotateX: 0,
              boxShadow: [
                "0 10px 30px rgba(104, 162, 214, 0.3)",
                "0 15px 40px rgba(104, 162, 214, 0.4)",
                "0 10px 30px rgba(104, 162, 214, 0.3)"
              ]
            } : {}}
            transition={{ 
              opacity: { delay: 0.5, duration: 0.5, ease: "easeOut" },
              y: { delay: 0.5, duration: 0.5, ease: "easeOut" },
              rotateX: { delay: 0.5, duration: 0.5, ease: "easeOut" },
              boxShadow: { delay: 1.0, duration: 2.5, repeat: Infinity, ease: "easeInOut" }
            }}
            whileHover={{ 
              scale: 1.05, 
              y: -10,
              rotateX: -5,
              rotateY: -5,
              boxShadow: "0 25px 50px rgba(104, 162, 214, 0.6)",
              transition: { duration: 0.3, ease: "easeOut" }
            }}
            whileTap={{ scale: 0.95, y: -2 }}
          >
            {/* Enhanced glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-sky-blue/40 to-steel-blue/40 blur-xl opacity-0 group-hover:opacity-80 transition-opacity duration-300 -z-10 scale-110"></div>
            
            {/* Animated background layer */}
            <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></div>
            
            {/* Professional border highlight */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-ice-blue/50 to-sky-blue/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -m-0.5 -z-10"></div>
            
            {/* Enhanced shimmer */}
            <div className="absolute inset-0 -left-6 w-8 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shimmer opacity-0 group-hover:opacity-100"></div>
            
            <div className="flex items-center justify-center space-x-3 relative z-10">
              <Calendar className="w-6 h-6" />
              <div className="font-poppins">
                <div className="tracking-wide drop-shadow-sm">POST AN EVENT</div>
                <div className="text-sm mt-1 opacity-80">Find talent instantly</div>
              </div>
            </div>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
