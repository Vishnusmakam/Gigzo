import { motion } from "framer-motion";
import { Search, DollarSign, GraduationCap, Star } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

const features = [
  {
    icon: Search,
    title: "Find Gigs",
    description: "Browse and apply for exciting opportunities at events, fests, and corporate gatherings.",
    color: "text-electric-purple"
  },
  {
    icon: DollarSign,
    title: "Earn Money", 
    description: "Get paid fairly for your time and skills while building your professional portfolio.",
    color: "text-aqua"
  },
  {
    icon: GraduationCap,
    title: "Gain Experience",
    description: "Learn new skills and gain valuable work experience in diverse event environments.",
    color: "text-electric-purple"
  },
  {
    icon: Star,
    title: "Get Rated",
    description: "Build your reputation through our rating system and unlock better opportunities.",
    color: "text-aqua"
  }
];

export default function WhatWeDo() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  return (
    <section id="what-we-do" className="py-20 gradient-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4 text-light-blue">What We Do</h2>
          <p className="text-xl text-light-blue-muted max-w-3xl mx-auto">
            Gigzo bridges the gap between talented students and event organizers, creating opportunities for growth and success.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-charcoal/30 p-8 rounded-xl hover:bg-charcoal/50 transition-all duration-300 text-center cursor-pointer"
            >
              <div className={`text-4xl mb-4 ${feature.color}`}>
                <feature.icon className="w-12 h-12 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-light-blue">{feature.title}</h3>
              <p className="text-light-blue-muted">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
