import { useState } from "react";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full bg-navy/90 backdrop-blur-md z-50 border-b border-charcoal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <img 
              src="@assets/Screenshot 2025-07-12 at 9.15.18 AM_1752867796911.png" 
              alt="Gigzo Logo" 
              className="h-10 w-auto object-contain"
            />
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection("home")}
              className="text-light-blue hover:text-steel-blue transition-colors"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("how-it-works")}
              className="text-light-blue hover:text-steel-blue transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection("testimonials")}
              className="text-light-blue hover:text-steel-blue transition-colors"
            >
              Testimonials
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="text-light-blue hover:text-steel-blue transition-colors"
            >
              Contact
            </button>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-light-blue hover:text-steel-blue"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-navy/95 backdrop-blur-md border-b border-charcoal"
          >
            <div className="px-4 py-4 space-y-4">
              <button 
                onClick={() => scrollToSection("home")}
                className="block text-light-blue hover:text-steel-blue transition-colors"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection("how-it-works")}
                className="block text-light-blue hover:text-steel-blue transition-colors"
              >
                How It Works
              </button>
              <button 
                onClick={() => scrollToSection("testimonials")}
                className="block text-light-blue hover:text-steel-blue transition-colors"
              >
                Testimonials
              </button>
              <button 
                onClick={() => scrollToSection("contact")}
                className="block text-light-blue hover:text-steel-blue transition-colors"
              >
                Contact
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
