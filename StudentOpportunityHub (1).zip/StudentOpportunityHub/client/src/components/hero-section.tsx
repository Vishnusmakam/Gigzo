import { motion } from "framer-motion";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-[75vh] flex items-center justify-center overflow-hidden bg-navy">
      {/* Gradient background */}
      <div className="absolute inset-0 z-0 gradient-bg"></div>
      
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="relative flex flex-col items-center space-y-4 md:space-y-6">
            <motion.span 
              className="text-5xl md:text-7xl font-bold text-ice-blue relative z-10 cursor-pointer select-none"
              style={{ 
                fontFamily: 'Poppins, sans-serif', 
                letterSpacing: '-0.02em',
                background: 'linear-gradient(135deg, hsl(205, 70%, 75%) 0%, hsl(210, 60%, 65%) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                rotateY: [0, 5, -5, 0]
              }}
              transition={{ 
                opacity: { delay: 0.2, duration: 0.6, ease: "easeOut" },
                y: { delay: 0.2, duration: 0.6, ease: "easeOut" },
                rotateY: { delay: 1, duration: 4, repeat: Infinity, ease: "easeInOut" }
              }}
              whileHover={{ 
                scale: 1.05,
                rotateX: 10,
                rotateY: 15,
                transition: { duration: 0.3, ease: "easeOut" }
              }}
              onHoverStart={() => {}}
              onHoverEnd={() => {}}
            >
              EARN.
            </motion.span>
            
            <motion.span 
              className="text-5xl md:text-7xl font-bold text-steel-blue relative z-20 cursor-pointer select-none"
              style={{ 
                fontFamily: 'Poppins, sans-serif', 
                letterSpacing: '-0.02em',
                background: 'linear-gradient(135deg, hsl(215, 45%, 55%) 0%, hsl(212, 55%, 50%) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                rotateZ: [0, 2, -2, 0]
              }}
              transition={{ 
                opacity: { delay: 0.4, duration: 0.6, ease: "easeOut" },
                y: { delay: 0.4, duration: 0.6, ease: "easeOut" },
                rotateZ: { delay: 1.5, duration: 3, repeat: Infinity, ease: "easeInOut" }
              }}
              whileHover={{ 
                scale: 1.05,
                rotateX: -10,
                rotateZ: 8,
                transition: { duration: 0.3, ease: "easeOut" }
              }}
            >
              LEARN.
            </motion.span>
            
            <motion.span 
              className="text-5xl md:text-7xl font-bold text-sky-blue relative z-10 cursor-pointer select-none"
              style={{ 
                fontFamily: 'Poppins, sans-serif', 
                letterSpacing: '-0.02em',
                background: 'linear-gradient(135deg, hsl(210, 60%, 65%) 0%, hsl(205, 70%, 75%) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                scale: [1, 1.02, 1]
              }}
              transition={{ 
                opacity: { delay: 0.6, duration: 0.6, ease: "easeOut" },
                y: { delay: 0.6, duration: 0.6, ease: "easeOut" },
                scale: { delay: 2, duration: 3.5, repeat: Infinity, ease: "easeInOut" }
              }}
              whileHover={{ 
                scale: 1.05,
                rotateY: -15,
                rotateX: 5,
                transition: { duration: 0.3, ease: "easeOut" }
              }}
            >
              GROW.
            </motion.span>
          </div>
          
          {/* Interactive floating elements */}
          <motion.div
            className="absolute -top-8 -left-8 w-3 h-3 bg-steel-blue rounded-full opacity-40 cursor-pointer"
            animate={{ 
              y: [0, -15, 0], 
              x: [0, 10, 0],
              scale: [1, 1.3, 1],
              opacity: [0.4, 0.8, 0.4]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            whileHover={{ scale: 2, opacity: 1 }}
            whileTap={{ scale: 0.8 }}
          />
          <motion.div
            className="absolute -bottom-6 -right-8 w-4 h-4 bg-sky-blue rounded-full opacity-35 cursor-pointer"
            animate={{ 
              y: [0, 12, 0], 
              x: [0, -12, 0],
              rotate: [0, 180, 360],
              opacity: [0.35, 0.7, 0.35]
            }}
            transition={{ 
              duration: 5, 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: 2
            }}
            whileHover={{ scale: 2, opacity: 1, rotate: 720 }}
            whileTap={{ scale: 0.8 }}
          />
          <motion.div
            className="absolute top-1/4 -right-10 w-2 h-2 bg-ice-blue rounded-full opacity-50 cursor-pointer"
            animate={{ 
              x: [0, -20, 0],
              y: [0, 10, 0],
              scale: [1, 1.5, 1],
              opacity: [0.5, 0.9, 0.5]
            }}
            transition={{ 
              duration: 6, 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: 1
            }}
            whileHover={{ scale: 2.5, opacity: 1 }}
            whileTap={{ scale: 0.6 }}
          />
          <motion.div
            className="absolute bottom-1/3 -left-12 w-2 h-2 bg-ocean-blue rounded-full opacity-45 cursor-pointer"
            animate={{ 
              x: [0, 15, 0],
              y: [0, -8, 0],
              rotate: [0, -180, -360],
              opacity: [0.45, 0.8, 0.45]
            }}
            transition={{ 
              duration: 7, 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: 0.5
            }}
            whileHover={{ scale: 2, opacity: 1, rotate: -720 }}
            whileTap={{ scale: 0.8 }}
          />
        </motion.div>



        <motion.div 
          className="flex flex-col sm:flex-row gap-4 justify-center mt-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <motion.button
            onClick={() => scrollToSection("cta-section")}
            className="group relative bg-gradient-to-r from-steel-blue to-ocean-blue text-light-blue px-12 py-4 rounded-xl text-lg font-bold shadow-2xl overflow-hidden backdrop-blur-sm border-2 border-ice-blue/40 transform perspective-1000"
            initial={{ opacity: 0, y: 20, rotateX: 15 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              rotateX: 0,
              boxShadow: [
                "0 10px 30px rgba(72, 133, 189, 0.3)",
                "0 15px 40px rgba(72, 133, 189, 0.4)",
                "0 10px 30px rgba(72, 133, 189, 0.3)"
              ]
            }}
            transition={{ 
              opacity: { delay: 1.0, duration: 0.5, ease: "easeOut" },
              y: { delay: 1.0, duration: 0.5, ease: "easeOut" },
              rotateX: { delay: 1.0, duration: 0.5, ease: "easeOut" },
              boxShadow: { delay: 1.5, duration: 2, repeat: Infinity, ease: "easeInOut" }
            }}
            whileHover={{ 
              scale: 1.05, 
              y: -8,
              rotateX: -5,
              rotateY: 5,
              boxShadow: "0 25px 50px rgba(72, 133, 189, 0.6)",
              transition: { duration: 0.3, ease: "easeOut" }
            }}
            whileTap={{ scale: 0.95, y: -2 }}
          >
            {/* Enhanced glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-steel-blue/40 to-ocean-blue/40 blur-xl opacity-0 group-hover:opacity-80 transition-opacity duration-300 -z-10 scale-110"></div>
            
            {/* Animated background layer */}
            <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
            
            {/* Professional border highlight */}
            <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-ice-blue/50 to-sky-blue/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -m-0.5 -z-10"></div>
            
            {/* Enhanced shimmer */}
            <div className="absolute inset-0 -left-6 w-8 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shimmer opacity-0 group-hover:opacity-100"></div>
            
            <span className="relative z-10 font-poppins tracking-wide drop-shadow-sm">Sign Up as Student</span>
          </motion.button>
          
          <motion.button
            onClick={() => scrollToSection("cta-section")}
            className="group relative bg-gradient-to-r from-sky-blue to-steel-blue text-light-blue px-12 py-4 rounded-xl text-lg font-bold shadow-2xl overflow-hidden backdrop-blur-sm border-2 border-ice-blue/40 transform perspective-1000"
            initial={{ opacity: 0, y: 20, rotateX: 15 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              rotateX: 0,
              boxShadow: [
                "0 10px 30px rgba(104, 162, 214, 0.3)",
                "0 15px 40px rgba(104, 162, 214, 0.4)",
                "0 10px 30px rgba(104, 162, 214, 0.3)"
              ]
            }}
            transition={{ 
              opacity: { delay: 1.2, duration: 0.5, ease: "easeOut" },
              y: { delay: 1.2, duration: 0.5, ease: "easeOut" },
              rotateX: { delay: 1.2, duration: 0.5, ease: "easeOut" },
              boxShadow: { delay: 2, duration: 2.5, repeat: Infinity, ease: "easeInOut" }
            }}
            whileHover={{ 
              scale: 1.05, 
              y: -8,
              rotateX: -5,
              rotateY: -5,
              boxShadow: "0 25px 50px rgba(104, 162, 214, 0.6)",
              transition: { duration: 0.3, ease: "easeOut" }
            }}
            whileTap={{ scale: 0.95, y: -2 }}
          >
            {/* Enhanced glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-sky-blue/40 to-steel-blue/40 blur-xl opacity-0 group-hover:opacity-80 transition-opacity duration-300 -z-10 scale-110"></div>
            
            {/* Animated background layer */}
            <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
            
            {/* Professional border highlight */}
            <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-ice-blue/50 to-sky-blue/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -m-0.5 -z-10"></div>
            
            {/* Enhanced shimmer */}
            <div className="absolute inset-0 -left-6 w-8 h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:animate-shimmer opacity-0 group-hover:opacity-100"></div>
            
            <span className="relative z-10 font-poppins tracking-wide drop-shadow-sm">Post an Event</span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
