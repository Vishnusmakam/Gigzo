import { motion } from "framer-motion";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";
import { useCounterAnimation } from "@/hooks/use-counter-animation";

const stats = [
  {
    value: 2500,
    label: "Gigs Completed",
    suffix: "",
    description: "And counting...",
    color: "text-electric-purple"
  },
  {
    value: 4.9,
    label: "Average Rating", 
    suffix: "",
    description: "Out of 5 stars",
    color: "text-aqua",
    isDecimal: true
  },
  {
    value: 95,
    label: "Repeat Rate %",
    suffix: "%",
    description: "Organizers come back",
    color: "text-electric-purple"
  }
];

const partnerLogos = [
  "IIT Delhi",
  "DU", 
  "BITS Pilani",
  "SRCC",
  "LSR"
];

function StatCard({ stat, delay }: { stat: any; delay: number }) {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.5 });
  const animatedValue = useCounterAnimation(isVisible ? stat.value : 0, 2000);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={isVisible ? { opacity: 1, scale: 1 } : {}}
      transition={{ delay, duration: 0.6 }}
      className="stat-card p-8 rounded-xl text-center"
    >
      <div className={`text-4xl font-bold ${stat.color} mb-2`}>
        {stat.isDecimal ? animatedValue.toFixed(1) : Math.floor(animatedValue)}
        {stat.suffix}
      </div>
      <div className="text-light-blue text-lg">{stat.label}</div>
      <div className="text-light-blue-muted text-sm mt-2">{stat.description}</div>
    </motion.div>
  );
}

export default function TrustScore() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  return (
    <section id="trust-score" className="py-20 bg-navy">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <motion.h2 
          className="text-4xl font-bold text-center mb-16 text-light-blue"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          Trusted by Thousands
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {stats.map((stat, index) => (
            <StatCard 
              key={stat.label}
              stat={stat}
              delay={0.2 + (index * 0.1)}
            />
          ))}
        </div>
        
        {/* Partner Logos */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <h3 className="text-2xl font-semibold text-center mb-8 text-light-blue">Trusted by Leading Institutions</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {partnerLogos.map((logo, index) => (
              <motion.div
                key={logo}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isVisible ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.6 + (index * 0.1), duration: 0.4 }}
                className="bg-light-blue/10 px-6 py-3 rounded-lg text-light-blue font-semibold hover:bg-light-blue/20 transition-colors cursor-pointer"
              >
                {logo}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
