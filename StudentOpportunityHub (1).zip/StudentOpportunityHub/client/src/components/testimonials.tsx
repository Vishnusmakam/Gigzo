import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

const studentTestimonials = [
  {
    name: "Raj Kumar",
    title: "Engineering Student, Delhi",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    quote: "I earned ₹15,000 in my first month working college fests. The experience was incredible and I learned so much about event management!",
    rating: 5
  },
  {
    name: "Priya Sharma", 
    title: "Business Student, Mumbai",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    quote: "Gigzo helped me build my portfolio while earning money. I've worked at 8 events and each one taught me something new!",
    rating: 5
  }
];

const organizerTestimonials = [
  {
    name: "David Chen",
    title: "Event Manager, TechCorp", 
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    quote: "Gigzo made staffing our tech summit incredibly easy. The students were professional, punctual, and eager to learn. We'll definitely use them again!",
    rating: 5
  },
  {
    name: "Sarah Johnson",
    title: "Marketing Director, ExpoWorld",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    quote: "The quality of talent on Gigzo is exceptional. We hired 20 students for our expo and they exceeded our expectations. Fast hiring, great results!",
    rating: 5
  }
];

function TestimonialCard({ testimonial, delay }: { testimonial: any; delay: number }) {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.3 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ delay, duration: 0.6 }}
      className="testimonial-card p-6 rounded-xl"
    >
      <div className="flex items-start space-x-4">
        <img 
          src={testimonial.image}
          alt={`${testimonial.name} testimonial`}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <p className="text-light-blue-muted mb-3 italic">"{testimonial.quote}"</p>
          <div className="text-light-blue font-semibold">{testimonial.name}</div>
          <div className="text-light-blue-muted text-sm">{testimonial.title}</div>
          <div className="flex space-x-1 mt-2">
            {[...Array(testimonial.rating)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Testimonials() {
  const { ref, isVisible } = useIntersectionObserver({ threshold: 0.1 });

  return (
    <section id="testimonials" className="py-20 gradient-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <motion.h2 
          className="text-4xl font-bold text-center mb-16 text-light-blue"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          What Our Users Say
        </motion.h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Student Testimonials */}
          <div>
            <motion.h3 
              className="text-2xl font-semibold mb-8 text-electric-purple text-center"
              initial={{ opacity: 0, x: -30 }}
              animate={isVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              Students
            </motion.h3>
            <div className="space-y-6">
              {studentTestimonials.map((testimonial, index) => (
                <TestimonialCard 
                  key={testimonial.name}
                  testimonial={testimonial}
                  delay={0.3 + (index * 0.1)}
                />
              ))}
            </div>
          </div>
          
          {/* Organizer Testimonials */}
          <div>
            <motion.h3 
              className="text-2xl font-semibold mb-8 text-electric-purple text-center"
              initial={{ opacity: 0, x: 30 }}
              animate={isVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              Organizers
            </motion.h3>
            <div className="space-y-6">
              {organizerTestimonials.map((testimonial, index) => (
                <TestimonialCard 
                  key={testimonial.name}
                  testimonial={testimonial}
                  delay={0.5 + (index * 0.1)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
