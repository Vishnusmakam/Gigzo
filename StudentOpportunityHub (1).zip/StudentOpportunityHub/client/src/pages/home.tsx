import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import WhatWeDo from "@/components/what-we-do";
import WhyUs from "@/components/why-us";
import HowItWorks from "@/components/how-it-works";
import CTASection from "@/components/cta-section";
import Testimonials from "@/components/testimonials";
import TrustScore from "@/components/trust-score";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-navy">
      <Navigation />
      <HeroSection />
      <WhatWeDo />
      <WhyUs />
      <HowItWorks />
      <CTASection />
      <Testimonials />
      <TrustScore />
      <Footer />
    </div>
  );
}
